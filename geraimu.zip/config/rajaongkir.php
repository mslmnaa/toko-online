<?php

return [
    'api_key' => env('RAJAONGKIR_API_KEY', 'ffb69bd300fd15bd5c4b81399ee3b217'),
    'base_url' => env('RAJAONGKIR_BASE_URL', 'https://api.rajaongkir.com/starter'),
    'origin_city' => env('RAJAONGKIR_ORIGIN_CITY', '419 '), // ID kota toko Anda
];