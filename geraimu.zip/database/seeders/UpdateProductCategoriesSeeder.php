<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

// class UpdateProductCategoriesSeeder extends Seeder
// {
//     public function run()
//     {
//         $products = Product::all();

//         foreach ($products as $product) {
//             $category = $this->getRandomCategory();
//             $product->update(['category' => $category]);
//         }
//     }

//     private function getRandomCategory()
//     {
//         $categories = ['coffee', 'tea', 'Refresh'];
//         return $categories[array_rand($categories)];
//     }
// }

